# STEP 7: Streamlit App Development
import streamlit as st
import pandas as pd
import numpy as np
import warnings
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity

# Load preprocessed data and models (placeholders for now)
@st.cache_data
def load_data():
    df = pd.read_csv('online_retail_cleaned.csv')  # Your cleaned dataset
    customer_product_matrix = pd.read_pickle('customer_product_matrix.pkl')
    product_similarity_df = pd.read_pickle('product_similarity_df.pkl')
    rfm_model = pd.read_pickle('kmeans_model.pkl')
    scaler = pd.read_pickle('scaler.pkl')
    return df, customer_product_matrix, product_similarity_df, rfm_model, scaler

df, customer_product_matrix, product_similarity_df, rfm_model, scaler = load_data()

st.title(" Shopper Spectrum: Product Recommender & Customer Segmentation")

# Tabs
tab1, tab2 = st.tabs(["Product Recommendation", "Customer Segmentation"])

# -------------------- TAB 1 --------------------
with tab1:
    st.header(" Product Recommendation")
    product_id = st.text_input("Enter Product StockCode (e.g., 85123A):")

    if st.button("Get Recommendations"):
        if product_id not in product_similarity_df.columns:
            st.warning("Product not found. Please try another StockCode.")
        else:
            similar_products = product_similarity_df[product_id].sort_values(ascending=False).iloc[1:6]
            st.success("Top 5 Similar Products:")
            for pid in similar_products.index:
                desc = df[df['StockCode'] == pid]['Description'].values[0]
                st.markdown(f"- **{pid}** → {desc}")

# -------------------- TAB 2 --------------------
with tab2:
    st.header(" Customer Segmentation")

    r = st.number_input("Recency (days since last purchase):", min_value=0)
    f = st.number_input("Frequency (number of purchases):", min_value=0)
    m = st.number_input("Monetary (total spend):", min_value=0)

    if st.button("Predict Segment"):
        input_scaled = scaler.transform([[r, f, m]])
        cluster_label = rfm_model.predict(input_scaled)[0]

        # Mapping cluster labels to segments (adjust if needed)
        segment_map = {
            0: "High-Value",
            1: "Regular",
            2: "Occasional",
            3: "At-Risk"
        }
        st.success(f"Predicted Segment: **{segment_map.get(cluster_label, 'Unknown')}**")

